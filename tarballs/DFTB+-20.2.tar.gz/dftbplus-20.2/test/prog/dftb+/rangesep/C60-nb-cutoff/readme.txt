SCC using a restarted range separation calculation
