Generate initial configuration and velocities for a subsequent MD calculation.
