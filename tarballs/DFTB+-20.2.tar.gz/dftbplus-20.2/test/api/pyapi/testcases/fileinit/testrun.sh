#!/bin/bash
set -e
python3 ./test_fileinit.py
