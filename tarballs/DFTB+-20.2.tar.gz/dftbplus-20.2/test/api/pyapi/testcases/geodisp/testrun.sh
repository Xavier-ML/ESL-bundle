#!/bin/bash
set -e
python3 ./test_geodisp.py
