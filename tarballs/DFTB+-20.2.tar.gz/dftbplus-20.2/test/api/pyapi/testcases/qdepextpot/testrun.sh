#!/bin/bash
set -e
python3 ./test_qdepextpot.py
