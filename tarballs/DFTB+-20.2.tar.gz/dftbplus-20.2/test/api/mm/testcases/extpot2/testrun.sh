#!/bin/sh
RUN_CMD="$@"
exec $RUN_CMD ../../testers/test_extpot2
