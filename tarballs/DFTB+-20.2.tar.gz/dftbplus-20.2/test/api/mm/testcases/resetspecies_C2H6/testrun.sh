RUN_CMD=$*
echo "$RUN_CMD ../../testers/test_setspeciesanddependents"
$RUN_CMD ../../testers/test_setspeciesanddependents
